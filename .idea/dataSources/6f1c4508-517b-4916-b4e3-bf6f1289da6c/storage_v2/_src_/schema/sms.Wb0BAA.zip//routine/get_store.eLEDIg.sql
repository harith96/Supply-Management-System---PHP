create function get_store(id int(10))
  returns varchar(20)
  BEGIN
      DECLARE s_city VARCHAR(20);
      SET s_city = (SELECT city FROM stores WHERE store_id = id);
      RETURN s_city;
    END;

